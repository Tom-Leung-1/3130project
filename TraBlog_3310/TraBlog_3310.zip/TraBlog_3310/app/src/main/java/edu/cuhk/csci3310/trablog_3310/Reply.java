package edu.cuhk.csci3310.trablog_3310;

public class Reply {
    private String user;
    private String content;

    public String getUser() {
        return user;
    }

    public String getContent() {
        return content;
    }
}